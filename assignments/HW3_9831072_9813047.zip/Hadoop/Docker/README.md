# About 
Cloud-computing course / Homework3 


# Install 
```bash
docker-compose up

```

# ToDo
After installation, 
open spark-assignment.ipynb in [jupyter-lab](http://127.0.0.1:8888) and fill out the blank cells
